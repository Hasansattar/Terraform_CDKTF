import { EventGridEvent, InvocationContext } from "@azure/functions";
export declare function eventGridTrigger(event: EventGridEvent, context: InvocationContext): Promise<void>;
