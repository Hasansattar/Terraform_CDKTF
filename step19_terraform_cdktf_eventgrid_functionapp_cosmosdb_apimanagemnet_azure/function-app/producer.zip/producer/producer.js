"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const eventgrid_1 = require("@azure/eventgrid");
// Get Event Grid settings from environment variables
// const eventGridEndpoint = process.env["EVENT_GRID_TOPIC_URL"]; // Event Grid Topic URL
const eventGridEndpoint = `https://${process.env.EVENT_GRID_TOPIC_NAME}.australiaeast-1.eventgrid.azure.net/api/events`;
const eventGridKey = `${process.env.EVENT_GRID_KEY}`; // Event Grid Access Key
// const eventGridKey = "12345678"
const httpTrigger = async function (context, req) {
    context.log("HTTP trigger function processed a request.");
    // Initialize EventGridPublisherClient
    const client = new eventgrid_1.EventGridPublisherClient(eventGridEndpoint, "EventGrid", // Using EventGrid schema
    new eventgrid_1.AzureKeyCredential(eventGridKey));
    context.log("client===>", client);
    // Create event data
    const eventData = req.body || {
        subject: "Sample.Subject",
        eventType: "Sample.EventType",
        data: {
            message: "Hello from Producer using EventGrid library!",
        },
        dataVersion: "1.0",
    };
    try {
        // Send event to Event Grid
        const sendEvent = await client.send([eventData]);
        context.log("sendEvent===>", sendEvent);
        context.res = {
            status: 200,
            body: "Event sent to Event Grid successfully!",
        };
    }
    catch (error) {
        context.log.error("Error sending event to Event Grid:", error);
        context.res = {
            status: 500,
            body: "Failed to send event to Event Grid",
        };
    }
};
exports.default = httpTrigger;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvZHVjZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJwcm9kdWNlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUNBLGdEQUFnRjtBQUVoRixxREFBcUQ7QUFDckQseUZBQXlGO0FBQ3pGLE1BQU0saUJBQWlCLEdBQUcsV0FBVyxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixpREFBaUQsQ0FBQztBQUNySCxNQUFNLFlBQVksR0FBRyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyx3QkFBd0I7QUFDakYsa0NBQWtDO0FBR2xDLE1BQU0sV0FBVyxHQUFrQixLQUFLLFdBQ3RDLE9BQWdCLEVBQ2hCLEdBQWdCO0lBRWhCLE9BQU8sQ0FBQyxHQUFHLENBQUMsNENBQTRDLENBQUMsQ0FBQztJQUUxRCxzQ0FBc0M7SUFDdEMsTUFBTSxNQUFNLEdBQUcsSUFBSSxvQ0FBd0IsQ0FDekMsaUJBQWlCLEVBQ2pCLFdBQVcsRUFBRSx5QkFBeUI7SUFDdEMsSUFBSSw4QkFBa0IsQ0FBQyxZQUFZLENBQUMsQ0FDckMsQ0FBQztJQUdGLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ2pDLG9CQUFvQjtJQUNwQixNQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsSUFBSSxJQUFJO1FBQzVCLE9BQU8sRUFBRSxnQkFBZ0I7UUFDekIsU0FBUyxFQUFFLGtCQUFrQjtRQUM3QixJQUFJLEVBQUU7WUFDSixPQUFPLEVBQUUsOENBQThDO1NBQ3hEO1FBQ0QsV0FBVyxFQUFFLEtBQUs7S0FDbkIsQ0FBQztJQUVGLElBQUksQ0FBQztRQUNILDJCQUEyQjtRQUMzQixNQUFNLFNBQVMsR0FBRSxNQUFNLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1FBRWhELE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxFQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRXZDLE9BQU8sQ0FBQyxHQUFHLEdBQUc7WUFDWixNQUFNLEVBQUUsR0FBRztZQUNYLElBQUksRUFBRSx3Q0FBd0M7U0FDL0MsQ0FBQztJQUNKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsb0NBQW9DLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFL0QsT0FBTyxDQUFDLEdBQUcsR0FBRztZQUNaLE1BQU0sRUFBRSxHQUFHO1lBQ1gsSUFBSSxFQUFFLG9DQUFvQztTQUMzQyxDQUFDO0lBQ0osQ0FBQztBQUNILENBQUMsQ0FBQztBQUVGLGtCQUFlLFdBQVcsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEF6dXJlRnVuY3Rpb24sIENvbnRleHQsIEh0dHBSZXF1ZXN0IH0gZnJvbSBcIkBhenVyZS9mdW5jdGlvbnNcIjtcclxuaW1wb3J0IHsgRXZlbnRHcmlkUHVibGlzaGVyQ2xpZW50LCBBenVyZUtleUNyZWRlbnRpYWwgfSBmcm9tIFwiQGF6dXJlL2V2ZW50Z3JpZFwiO1xyXG5cclxuLy8gR2V0IEV2ZW50IEdyaWQgc2V0dGluZ3MgZnJvbSBlbnZpcm9ubWVudCB2YXJpYWJsZXNcclxuLy8gY29uc3QgZXZlbnRHcmlkRW5kcG9pbnQgPSBwcm9jZXNzLmVudltcIkVWRU5UX0dSSURfVE9QSUNfVVJMXCJdOyAvLyBFdmVudCBHcmlkIFRvcGljIFVSTFxyXG5jb25zdCBldmVudEdyaWRFbmRwb2ludCA9IGBodHRwczovLyR7cHJvY2Vzcy5lbnYuRVZFTlRfR1JJRF9UT1BJQ19OQU1FfS5hdXN0cmFsaWFlYXN0LTEuZXZlbnRncmlkLmF6dXJlLm5ldC9hcGkvZXZlbnRzYDtcclxuICAgY29uc3QgZXZlbnRHcmlkS2V5ID0gYCR7cHJvY2Vzcy5lbnYuRVZFTlRfR1JJRF9LRVl9YDsgLy8gRXZlbnQgR3JpZCBBY2Nlc3MgS2V5XHJcbi8vIGNvbnN0IGV2ZW50R3JpZEtleSA9IFwiMTIzNDU2NzhcIlxyXG5cclxuXHJcbmNvbnN0IGh0dHBUcmlnZ2VyOiBBenVyZUZ1bmN0aW9uID0gYXN5bmMgZnVuY3Rpb24gKFxyXG4gIGNvbnRleHQ6IENvbnRleHQsXHJcbiAgcmVxOiBIdHRwUmVxdWVzdFxyXG4pOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb250ZXh0LmxvZyhcIkhUVFAgdHJpZ2dlciBmdW5jdGlvbiBwcm9jZXNzZWQgYSByZXF1ZXN0LlwiKTtcclxuXHJcbiAgLy8gSW5pdGlhbGl6ZSBFdmVudEdyaWRQdWJsaXNoZXJDbGllbnRcclxuICBjb25zdCBjbGllbnQgPSBuZXcgRXZlbnRHcmlkUHVibGlzaGVyQ2xpZW50KFxyXG4gICAgZXZlbnRHcmlkRW5kcG9pbnQsXHJcbiAgICBcIkV2ZW50R3JpZFwiLCAvLyBVc2luZyBFdmVudEdyaWQgc2NoZW1hXHJcbiAgICBuZXcgQXp1cmVLZXlDcmVkZW50aWFsKGV2ZW50R3JpZEtleSlcclxuICApO1xyXG5cclxuXHJcbiAgY29udGV4dC5sb2coXCJjbGllbnQ9PT0+XCIsY2xpZW50KTtcclxuICAvLyBDcmVhdGUgZXZlbnQgZGF0YVxyXG4gIGNvbnN0IGV2ZW50RGF0YSA9IHJlcS5ib2R5IHx8IHtcclxuICAgIHN1YmplY3Q6IFwiU2FtcGxlLlN1YmplY3RcIixcclxuICAgIGV2ZW50VHlwZTogXCJTYW1wbGUuRXZlbnRUeXBlXCIsXHJcbiAgICBkYXRhOiB7XHJcbiAgICAgIG1lc3NhZ2U6IFwiSGVsbG8gZnJvbSBQcm9kdWNlciB1c2luZyBFdmVudEdyaWQgbGlicmFyeSFcIixcclxuICAgIH0sXHJcbiAgICBkYXRhVmVyc2lvbjogXCIxLjBcIixcclxuICB9O1xyXG5cclxuICB0cnkge1xyXG4gICAgLy8gU2VuZCBldmVudCB0byBFdmVudCBHcmlkXHJcbiAgICBjb25zdCBzZW5kRXZlbnQ9IGF3YWl0IGNsaWVudC5zZW5kKFtldmVudERhdGFdKTtcclxuXHJcbiAgICBjb250ZXh0LmxvZyhcInNlbmRFdmVudD09PT5cIixzZW5kRXZlbnQpO1xyXG5cclxuICAgIGNvbnRleHQucmVzID0ge1xyXG4gICAgICBzdGF0dXM6IDIwMCxcclxuICAgICAgYm9keTogXCJFdmVudCBzZW50IHRvIEV2ZW50IEdyaWQgc3VjY2Vzc2Z1bGx5IVwiLFxyXG4gICAgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29udGV4dC5sb2cuZXJyb3IoXCJFcnJvciBzZW5kaW5nIGV2ZW50IHRvIEV2ZW50IEdyaWQ6XCIsIGVycm9yKTtcclxuXHJcbiAgICBjb250ZXh0LnJlcyA9IHtcclxuICAgICAgc3RhdHVzOiA1MDAsXHJcbiAgICAgIGJvZHk6IFwiRmFpbGVkIHRvIHNlbmQgZXZlbnQgdG8gRXZlbnQgR3JpZFwiLFxyXG4gICAgfTtcclxuICB9XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBodHRwVHJpZ2dlcjtcclxuIl19