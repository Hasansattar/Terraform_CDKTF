import { AzureFunction } from "@azure/functions";
declare const httpTrigger: AzureFunction;
export default httpTrigger;
