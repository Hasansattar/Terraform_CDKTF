type AppSyncEvent = {
    info: {
        fieldName: string;
    };
    arguments: {
        title?: string;
        product?: Product;
    };
};
type Product = {
    name: string;
    price: number;
};
