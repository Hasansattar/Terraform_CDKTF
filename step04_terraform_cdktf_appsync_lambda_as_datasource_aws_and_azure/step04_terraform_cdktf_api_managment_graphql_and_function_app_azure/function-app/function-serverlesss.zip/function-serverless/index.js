"use strict";
// module.exports = async function (context:any, req:any) {
//   const query = req.body.query;
//   let name = "World"; // default value
//   // Parse the query to get the "name" argument if provided
//   if (query.includes("hello") && query.includes("name")) {
//       const queryNameMatch = query.match(/name\s*:\s*"([^"]*)"/);
//       if (queryNameMatch && queryNameMatch[1]) {
//           name = queryNameMatch[1];
//       }
//   }
//   context.res = {
//       // Respond with a greeting message
//       body: JSON.stringify({
//           data: {
//               hello: `Hello, ${name}!`
//           }
//       }),
//       headers: { 'Content-Type': 'application/json' }
//   };
// };
const { v4: uuidv4 } = require('uuid'); // For generating unique IDs for users
let users = []; // Temporary in-memory storage for users
module.exports = async function (context, req) {
    const query = req.body.query;
    // Handle different GraphQL queries and mutations
    if (query.includes('hello')) {
        context.res = {
            body: JSON.stringify({
                data: {
                    hello: 'Hello, World!'
                }
            }),
            headers: { 'Content-Type': 'application/json' }
        };
        return;
    }
    if (query.includes('getUser')) {
        const idMatch = query.match(/id\s*:\s*"([^"]*)"/);
        if (idMatch && idMatch[1]) {
            const user = users.find((u) => u.id === idMatch[1]);
            if (user) {
                context.res = {
                    body: JSON.stringify({
                        data: {
                            getUser: user
                        }
                    }),
                    headers: { 'Content-Type': 'application/json' }
                };
            }
            else {
                context.res = {
                    status: 404,
                    body: JSON.stringify({
                        errors: [{ message: 'User not found' }]
                    }),
                    headers: { 'Content-Type': 'application/json' }
                };
            }
        }
        return;
    }
    if (query.includes('createUser')) {
        const nameMatch = query.match(/name\s*:\s*"([^"]*)"/);
        const emailMatch = query.match(/email\s*:\s*"([^"]*)"/);
        if (nameMatch && emailMatch && nameMatch[1] && emailMatch[1]) {
            const newUser = {
                id: uuidv4(),
                name: nameMatch[1],
                email: emailMatch[1]
            };
            users.push(newUser);
            context.res = {
                body: JSON.stringify({
                    data: {
                        createUser: newUser
                    }
                }),
                headers: { 'Content-Type': 'application/json' }
            };
        }
        else {
            context.res = {
                status: 400,
                body: JSON.stringify({
                    errors: [{ message: 'Invalid input' }]
                }),
                headers: { 'Content-Type': 'application/json' }
            };
        }
        return;
    }
    // If no valid query/mutation was found, return an error
    context.res = {
        status: 400,
        body: JSON.stringify({
            errors: [{ message: 'Invalid query or mutation' }]
        }),
        headers: { 'Content-Type': 'application/json' }
    };
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsMkRBQTJEO0FBQzNELGtDQUFrQztBQUNsQyx5Q0FBeUM7QUFFekMsOERBQThEO0FBQzlELDZEQUE2RDtBQUM3RCxvRUFBb0U7QUFDcEUsbURBQW1EO0FBQ25ELHNDQUFzQztBQUN0QyxVQUFVO0FBQ1YsTUFBTTtBQUVOLG9CQUFvQjtBQUNwQiwyQ0FBMkM7QUFDM0MsK0JBQStCO0FBQy9CLG9CQUFvQjtBQUNwQix5Q0FBeUM7QUFDekMsY0FBYztBQUNkLFlBQVk7QUFDWix3REFBd0Q7QUFDeEQsT0FBTztBQUNQLEtBQUs7QUFHTCxNQUFNLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHNDQUFzQztBQUU5RSxJQUFJLEtBQUssR0FBTyxFQUFFLENBQUMsQ0FBQyx3Q0FBd0M7QUFFNUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxLQUFLLFdBQVcsT0FBVyxFQUFFLEdBQU87SUFDakQsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7SUFFN0IsaURBQWlEO0lBQ2pELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1FBQzFCLE9BQU8sQ0FBQyxHQUFHLEdBQUc7WUFDVixJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDakIsSUFBSSxFQUFFO29CQUNGLEtBQUssRUFBRSxlQUFlO2lCQUN6QjthQUNKLENBQUM7WUFDRixPQUFPLEVBQUUsRUFBRSxjQUFjLEVBQUUsa0JBQWtCLEVBQUU7U0FDbEQsQ0FBQztRQUNGLE9BQU87SUFDWCxDQUFDO0lBRUQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7UUFDNUIsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBQ2xELElBQUksT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQ3hCLE1BQU0sSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFlLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbEUsSUFBSSxJQUFJLEVBQUUsQ0FBQztnQkFDUCxPQUFPLENBQUMsR0FBRyxHQUFHO29CQUNWLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO3dCQUNqQixJQUFJLEVBQUU7NEJBQ0YsT0FBTyxFQUFFLElBQUk7eUJBQ2hCO3FCQUNKLENBQUM7b0JBQ0YsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLGtCQUFrQixFQUFFO2lCQUNsRCxDQUFDO1lBQ04sQ0FBQztpQkFBTSxDQUFDO2dCQUNKLE9BQU8sQ0FBQyxHQUFHLEdBQUc7b0JBQ1YsTUFBTSxFQUFFLEdBQUc7b0JBQ1gsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7d0JBQ2pCLE1BQU0sRUFBRSxDQUFDLEVBQUUsT0FBTyxFQUFFLGdCQUFnQixFQUFFLENBQUM7cUJBQzFDLENBQUM7b0JBQ0YsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLGtCQUFrQixFQUFFO2lCQUNsRCxDQUFDO1lBQ04sQ0FBQztRQUNMLENBQUM7UUFDRCxPQUFPO0lBQ1gsQ0FBQztJQUVELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1FBQy9CLE1BQU0sU0FBUyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsc0JBQXNCLENBQUMsQ0FBQztRQUN0RCxNQUFNLFVBQVUsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLHVCQUF1QixDQUFDLENBQUM7UUFDeEQsSUFBSSxTQUFTLElBQUksVUFBVSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztZQUMzRCxNQUFNLE9BQU8sR0FBRztnQkFDWixFQUFFLEVBQUUsTUFBTSxFQUFFO2dCQUNaLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUNsQixLQUFLLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQzthQUN2QixDQUFDO1lBQ0YsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUVwQixPQUFPLENBQUMsR0FBRyxHQUFHO2dCQUNWLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO29CQUNqQixJQUFJLEVBQUU7d0JBQ0YsVUFBVSxFQUFFLE9BQU87cUJBQ3RCO2lCQUNKLENBQUM7Z0JBQ0YsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLGtCQUFrQixFQUFFO2FBQ2xELENBQUM7UUFDTixDQUFDO2FBQU0sQ0FBQztZQUNKLE9BQU8sQ0FBQyxHQUFHLEdBQUc7Z0JBQ1YsTUFBTSxFQUFFLEdBQUc7Z0JBQ1gsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7b0JBQ2pCLE1BQU0sRUFBRSxDQUFDLEVBQUUsT0FBTyxFQUFFLGVBQWUsRUFBRSxDQUFDO2lCQUN6QyxDQUFDO2dCQUNGLE9BQU8sRUFBRSxFQUFFLGNBQWMsRUFBRSxrQkFBa0IsRUFBRTthQUNsRCxDQUFDO1FBQ04sQ0FBQztRQUNELE9BQU87SUFDWCxDQUFDO0lBRUQsd0RBQXdEO0lBQ3hELE9BQU8sQ0FBQyxHQUFHLEdBQUc7UUFDVixNQUFNLEVBQUUsR0FBRztRQUNYLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO1lBQ2pCLE1BQU0sRUFBRSxDQUFDLEVBQUUsT0FBTyxFQUFFLDJCQUEyQixFQUFFLENBQUM7U0FDckQsQ0FBQztRQUNGLE9BQU8sRUFBRSxFQUFFLGNBQWMsRUFBRSxrQkFBa0IsRUFBRTtLQUNsRCxDQUFDO0FBQ04sQ0FBQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLy8gbW9kdWxlLmV4cG9ydHMgPSBhc3luYyBmdW5jdGlvbiAoY29udGV4dDphbnksIHJlcTphbnkpIHtcclxuLy8gICBjb25zdCBxdWVyeSA9IHJlcS5ib2R5LnF1ZXJ5O1xyXG4vLyAgIGxldCBuYW1lID0gXCJXb3JsZFwiOyAvLyBkZWZhdWx0IHZhbHVlXHJcbiAgXHJcbi8vICAgLy8gUGFyc2UgdGhlIHF1ZXJ5IHRvIGdldCB0aGUgXCJuYW1lXCIgYXJndW1lbnQgaWYgcHJvdmlkZWRcclxuLy8gICBpZiAocXVlcnkuaW5jbHVkZXMoXCJoZWxsb1wiKSAmJiBxdWVyeS5pbmNsdWRlcyhcIm5hbWVcIikpIHtcclxuLy8gICAgICAgY29uc3QgcXVlcnlOYW1lTWF0Y2ggPSBxdWVyeS5tYXRjaCgvbmFtZVxccyo6XFxzKlwiKFteXCJdKilcIi8pO1xyXG4vLyAgICAgICBpZiAocXVlcnlOYW1lTWF0Y2ggJiYgcXVlcnlOYW1lTWF0Y2hbMV0pIHtcclxuLy8gICAgICAgICAgIG5hbWUgPSBxdWVyeU5hbWVNYXRjaFsxXTtcclxuLy8gICAgICAgfVxyXG4vLyAgIH1cclxuXHJcbi8vICAgY29udGV4dC5yZXMgPSB7XHJcbi8vICAgICAgIC8vIFJlc3BvbmQgd2l0aCBhIGdyZWV0aW5nIG1lc3NhZ2VcclxuLy8gICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4vLyAgICAgICAgICAgZGF0YToge1xyXG4vLyAgICAgICAgICAgICAgIGhlbGxvOiBgSGVsbG8sICR7bmFtZX0hYFxyXG4vLyAgICAgICAgICAgfVxyXG4vLyAgICAgICB9KSxcclxuLy8gICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH1cclxuLy8gICB9O1xyXG4vLyB9O1xyXG5cclxuXHJcbmNvbnN0IHsgdjQ6IHV1aWR2NCB9ID0gcmVxdWlyZSgndXVpZCcpOyAvLyBGb3IgZ2VuZXJhdGluZyB1bmlxdWUgSURzIGZvciB1c2Vyc1xyXG5cclxubGV0IHVzZXJzOmFueSA9IFtdOyAvLyBUZW1wb3JhcnkgaW4tbWVtb3J5IHN0b3JhZ2UgZm9yIHVzZXJzXHJcblxyXG5tb2R1bGUuZXhwb3J0cyA9IGFzeW5jIGZ1bmN0aW9uIChjb250ZXh0OmFueSwgcmVxOmFueSkge1xyXG4gICAgY29uc3QgcXVlcnkgPSByZXEuYm9keS5xdWVyeTtcclxuXHJcbiAgICAvLyBIYW5kbGUgZGlmZmVyZW50IEdyYXBoUUwgcXVlcmllcyBhbmQgbXV0YXRpb25zXHJcbiAgICBpZiAocXVlcnkuaW5jbHVkZXMoJ2hlbGxvJykpIHtcclxuICAgICAgICBjb250ZXh0LnJlcyA9IHtcclxuICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgICAgICAgIGhlbGxvOiAnSGVsbG8sIFdvcmxkISdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHF1ZXJ5LmluY2x1ZGVzKCdnZXRVc2VyJykpIHtcclxuICAgICAgICBjb25zdCBpZE1hdGNoID0gcXVlcnkubWF0Y2goL2lkXFxzKjpcXHMqXCIoW15cIl0qKVwiLyk7XHJcbiAgICAgICAgaWYgKGlkTWF0Y2ggJiYgaWRNYXRjaFsxXSkge1xyXG4gICAgICAgICAgICBjb25zdCB1c2VyID0gdXNlcnMuZmluZCgodTogeyBpZDogYW55OyB9KSA9PiB1LmlkID09PSBpZE1hdGNoWzFdKTtcclxuICAgICAgICAgICAgaWYgKHVzZXIpIHtcclxuICAgICAgICAgICAgICAgIGNvbnRleHQucmVzID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZ2V0VXNlcjogdXNlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgICAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH1cclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjb250ZXh0LnJlcyA9IHtcclxuICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IDQwNCxcclxuICAgICAgICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yczogW3sgbWVzc2FnZTogJ1VzZXIgbm90IGZvdW5kJyB9XVxyXG4gICAgICAgICAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICAgICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9XHJcbiAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAocXVlcnkuaW5jbHVkZXMoJ2NyZWF0ZVVzZXInKSkge1xyXG4gICAgICAgIGNvbnN0IG5hbWVNYXRjaCA9IHF1ZXJ5Lm1hdGNoKC9uYW1lXFxzKjpcXHMqXCIoW15cIl0qKVwiLyk7XHJcbiAgICAgICAgY29uc3QgZW1haWxNYXRjaCA9IHF1ZXJ5Lm1hdGNoKC9lbWFpbFxccyo6XFxzKlwiKFteXCJdKilcIi8pO1xyXG4gICAgICAgIGlmIChuYW1lTWF0Y2ggJiYgZW1haWxNYXRjaCAmJiBuYW1lTWF0Y2hbMV0gJiYgZW1haWxNYXRjaFsxXSkge1xyXG4gICAgICAgICAgICBjb25zdCBuZXdVc2VyID0ge1xyXG4gICAgICAgICAgICAgICAgaWQ6IHV1aWR2NCgpLFxyXG4gICAgICAgICAgICAgICAgbmFtZTogbmFtZU1hdGNoWzFdLFxyXG4gICAgICAgICAgICAgICAgZW1haWw6IGVtYWlsTWF0Y2hbMV1cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgdXNlcnMucHVzaChuZXdVc2VyKTtcclxuXHJcbiAgICAgICAgICAgIGNvbnRleHQucmVzID0ge1xyXG4gICAgICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3JlYXRlVXNlcjogbmV3VXNlclxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH1cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjb250ZXh0LnJlcyA9IHtcclxuICAgICAgICAgICAgICAgIHN0YXR1czogNDAwLFxyXG4gICAgICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgICAgICAgICAgIGVycm9yczogW3sgbWVzc2FnZTogJ0ludmFsaWQgaW5wdXQnIH1dXHJcbiAgICAgICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICAvLyBJZiBubyB2YWxpZCBxdWVyeS9tdXRhdGlvbiB3YXMgZm91bmQsIHJldHVybiBhbiBlcnJvclxyXG4gICAgY29udGV4dC5yZXMgPSB7XHJcbiAgICAgICAgc3RhdHVzOiA0MDAsXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgICBlcnJvcnM6IFt7IG1lc3NhZ2U6ICdJbnZhbGlkIHF1ZXJ5IG9yIG11dGF0aW9uJyB9XVxyXG4gICAgICAgIH0pLFxyXG4gICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9XHJcbiAgICB9O1xyXG59O1xyXG5cclxuIl19