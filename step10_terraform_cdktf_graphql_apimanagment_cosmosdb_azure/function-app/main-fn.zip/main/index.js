"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = void 0;
const apollo_server_azure_functions_1 = require("apollo-server-azure-functions");
const apollo_server_core_1 = require("apollo-server-core");
const cosmos_1 = require("@azure/cosmos");
const client = new cosmos_1.CosmosClient(process.env.COSMOS_CONNECTION_STRING);
const database = client.database(process.env.DATABASE_NAME);
const container = database.container(process.env.TODOS_CONTAINER);
// GraphQL Schema
const typeDefs = (0, apollo_server_core_1.gql) `
  type Todo {
    id: ID!
    title: String!
    done: Boolean!
  }

  input TodoInput {
    id: ID!
    title: String!
    done: Boolean!
  }

  type Query {
    getTodos: [Todo]
  }

  type Mutation {
    addTodo(todo: TodoInput!): Todo
    updateTodo(todo: TodoInput!): Todo
    deleteTodo(todoId: String!): String
  }
`;
// Resolvers
const resolvers = {
    Query: {
        getTodos: async (_, __, context) => {
            context.log('Fetching all todos...');
            try {
                const { resources } = await container.items.readAll().fetchAll();
                context.log(`Successfully fetched ${resources.length} todos.`);
                const listOfData = resources.map((todo) => ({
                    id: todo.id,
                    title: todo.title,
                    done: todo.done,
                }));
                context.log(`Successfully fetched List`, listOfData);
                return listOfData;
            }
            catch (error) {
                context.log('Error fetching todos:', error);
                throw new Error('Failed to fetch todos.');
            }
        },
    },
    Mutation: {
        addTodo: async (_, { todo }, context) => {
            context.log('Adding a new todo...');
            console.log('Adding a new todo...');
            const newTodo = {
                id: todo.id,
                title: todo.title,
                done: todo.done || false, // Default value for done
            };
            try {
                const { resource } = await container.items.create(newTodo);
                context.log('Todo added successfully:', resource);
                if (!resource) {
                    throw new Error('Failed to create todo.');
                }
                return {
                    id: resource.id,
                    title: resource.title,
                    done: resource.done,
                };
            }
            catch (error) {
                context.log('Error adding todo:', error);
                throw new Error('Failed to add todo.');
            }
        },
        updateTodo: async (_, { todo }, context) => {
            context.log(`Updating todo with ID: ${todo.id}`);
            try {
                const partitionKeyValue = todo.id;
                const { resource } = await container.item(todo.id, partitionKeyValue).read();
                const updatedTodo = { ...resource, title: todo.title, done: todo.done };
                const { resource: updatedResource } = await container.item(todo.id, partitionKeyValue).replace(updatedTodo);
                context.log('Todo updated successfully:', updatedResource);
                return updatedResource;
            }
            catch (error) {
                context.log('Error updating todo:', error);
                throw new Error('Failed to update todo.');
            }
        },
        deleteTodo: async (_, { todoId }, context) => {
            context.log(`Deleting todo with ID: ${todoId}`);
            try {
                // Replace `<partitionKeyValue>` with the actual partition key value for the todos.
                const partitionKeyValue = todoId; // Assuming `id` is used as the partition key
                const resource1 = await container.item(todoId, partitionKeyValue).read();
                context.log(`NUMBER - resource1 `, resource1);
                const { resource: existingTodo } = await container.item(todoId, partitionKeyValue).read();
                if (!existingTodo) {
                    context.log(`Todo with ID ${todoId} does not exist.`);
                    throw new Error(`Todo with ID ${todoId} does not exist.`);
                }
                context.log(`Todo with ID ${todoId} does exist.`);
                await container.item(todoId, partitionKeyValue).delete();
                context.log(`Todo with ID ${todoId} deleted successfully.`);
                return todoId;
            }
            catch (error) {
                context.log('Error deleting todo:', error);
                throw new Error('Failed to delete todo.');
            }
        },
    },
};
// Apollo Server setup
const server = new apollo_server_azure_functions_1.ApolloServer({
    typeDefs,
    resolvers,
    context: ({ context }) => context,
});
const main = (context, req) => {
    context.log('Received request:', req.body);
    return server.createHandler()(context, req);
};
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxpRkFBNkQ7QUFDN0QsMkRBQXlDO0FBQ3pDLDBDQUE2QztBQUc3QyxNQUFNLE1BQU0sR0FBRyxJQUFJLHFCQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBa0MsQ0FBQyxDQUFDO0FBQ2hGLE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUF1QixDQUFDLENBQUM7QUFDdEUsTUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQXlCLENBQUMsQ0FBQztBQUU1RSxpQkFBaUI7QUFDakIsTUFBTSxRQUFRLEdBQUcsSUFBQSx3QkFBRyxFQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBc0JuQixDQUFDO0FBRUYsWUFBWTtBQUNaLE1BQU0sU0FBUyxHQUFHO0lBQ2hCLEtBQUssRUFBRTtRQUNMLFFBQVEsRUFBRSxLQUFLLEVBQUUsQ0FBTSxFQUFFLEVBQU8sRUFBRSxPQUFnQixFQUFFLEVBQUU7WUFDcEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1lBQ3JDLElBQUksQ0FBQztnQkFDSCxNQUFNLEVBQUUsU0FBUyxFQUFFLEdBQUcsTUFBTSxTQUFTLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDO2dCQUNqRSxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixTQUFTLENBQUMsTUFBTSxTQUFTLENBQUMsQ0FBQztnQkFDL0QsTUFBTSxVQUFVLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQVMsRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDL0MsRUFBRSxFQUFFLElBQUksQ0FBQyxFQUFFO29CQUNYLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztvQkFDakIsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO2lCQUNoQixDQUFDLENBQUMsQ0FBQztnQkFFSixPQUFPLENBQUMsR0FBRyxDQUFDLDJCQUEyQixFQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUNwRCxPQUFPLFVBQVUsQ0FBQztZQUlwQixDQUFDO1lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztnQkFDZixPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUM1QyxNQUFNLElBQUksS0FBSyxDQUFDLHdCQUF3QixDQUFDLENBQUM7WUFDNUMsQ0FBQztRQUNILENBQUM7S0FDRjtJQUNELFFBQVEsRUFBRTtRQUNSLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBTSxFQUFFLEVBQUUsSUFBSSxFQUFPLEVBQUUsT0FBZ0IsRUFBRSxFQUFFO1lBQ3pELE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsQ0FBQztZQUNwQyxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLENBQUE7WUFDbkMsTUFBTSxPQUFPLEdBQUc7Z0JBQ2QsRUFBRSxFQUFFLElBQUksQ0FBQyxFQUFFO2dCQUNYLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztnQkFDakIsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLElBQUksS0FBSyxFQUFFLHlCQUF5QjthQUNwRCxDQUFDO1lBQ0YsSUFBSSxDQUFDO2dCQUNILE1BQU0sRUFBRSxRQUFRLEVBQUUsR0FBRyxNQUFNLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUMzRCxPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixFQUFFLFFBQVEsQ0FBQyxDQUFDO2dCQUNsRCxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7b0JBQ2QsTUFBTSxJQUFJLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO2dCQUM1QyxDQUFDO2dCQUVELE9BQU87b0JBQ0wsRUFBRSxFQUFFLFFBQVEsQ0FBQyxFQUFFO29CQUNmLEtBQUssRUFBRSxRQUFRLENBQUMsS0FBSztvQkFDckIsSUFBSSxFQUFFLFFBQVEsQ0FBQyxJQUFJO2lCQUNwQixDQUFDO1lBQ0osQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztnQkFDekMsTUFBTSxJQUFJLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO1lBQ3pDLENBQUM7UUFDSCxDQUFDO1FBQ0QsVUFBVSxFQUFFLEtBQUssRUFBRSxDQUFNLEVBQUUsRUFBRSxJQUFJLEVBQU8sRUFBRSxPQUFnQixFQUFHLEVBQUU7WUFDN0QsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDakQsSUFBSSxDQUFDO2dCQUNILE1BQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLEVBQUUsQ0FBQztnQkFDbEMsTUFBTSxFQUFFLFFBQVEsRUFBRSxHQUFHLE1BQU0sU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFDLGlCQUFpQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQzVFLE1BQU0sV0FBVyxHQUFHLEVBQUUsR0FBRyxRQUFRLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFFeEUsTUFBTSxFQUFFLFFBQVEsRUFBRSxlQUFlLEVBQUUsR0FBRyxNQUFNLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBQyxpQkFBaUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDM0csT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsRUFBRSxlQUFlLENBQUMsQ0FBQztnQkFDM0QsT0FBTyxlQUFlLENBQUM7WUFDekIsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsRUFBRSxLQUFLLENBQUMsQ0FBQztnQkFDM0MsTUFBTSxJQUFJLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1lBQzVDLENBQUM7UUFDSCxDQUFDO1FBQ0QsVUFBVSxFQUFFLEtBQUssRUFBRSxDQUFNLEVBQUUsRUFBRSxNQUFNLEVBQU8sRUFBRSxPQUFnQixFQUFHLEVBQUU7WUFHL0QsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUVoRCxJQUFJLENBQUM7Z0JBRUUsbUZBQW1GO2dCQUNwRixNQUFNLGlCQUFpQixHQUFHLE1BQU0sQ0FBQyxDQUFDLDZDQUE2QztnQkFDbkYsTUFBTSxTQUFTLEdBQUcsTUFBTSxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBQyxpQkFBaUIsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUN4RSxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixFQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUM3QyxNQUFNLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxHQUFHLE1BQU0sU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFFMUYsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO29CQUNsQixPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixNQUFNLGtCQUFrQixDQUFDLENBQUM7b0JBQ3RELE1BQU0sSUFBSSxLQUFLLENBQUMsZ0JBQWdCLE1BQU0sa0JBQWtCLENBQUMsQ0FBQztnQkFDNUQsQ0FBQztnQkFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixNQUFNLGNBQWMsQ0FBQyxDQUFDO2dCQUVsRCxNQUFNLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFDLGlCQUFpQixDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBRXhELE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLE1BQU0sd0JBQXdCLENBQUMsQ0FBQztnQkFDNUQsT0FBTyxNQUFNLENBQUM7WUFDaEIsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsRUFBRSxLQUFLLENBQUMsQ0FBQztnQkFDM0MsTUFBTSxJQUFJLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1lBQzVDLENBQUM7UUFDSCxDQUFDO0tBQ0Y7Q0FDRixDQUFDO0FBRUYsc0JBQXNCO0FBQ3RCLE1BQU0sTUFBTSxHQUFHLElBQUksNENBQVksQ0FBQztJQUM5QixRQUFRO0lBQ1IsU0FBUztJQUNULE9BQU8sRUFBRSxDQUFDLEVBQUUsT0FBTyxFQUF5QixFQUFFLEVBQUUsQ0FBQyxPQUFPO0NBQ3pELENBQUMsQ0FBQztBQUVJLE1BQU0sSUFBSSxHQUFHLENBQUMsT0FBZ0IsRUFBRyxHQUFRLEVBQUUsRUFBRTtJQUNsRCxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUMzQyxPQUFPLE1BQU0sQ0FBQyxhQUFhLEVBQUUsQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUM7QUFDOUMsQ0FBQyxDQUFDO0FBSFcsUUFBQSxJQUFJLFFBR2YiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBcG9sbG9TZXJ2ZXIgfSBmcm9tICdhcG9sbG8tc2VydmVyLWF6dXJlLWZ1bmN0aW9ucyc7XHJcbmltcG9ydCB7IGdxbCB9IGZyb20gJ2Fwb2xsby1zZXJ2ZXItY29yZSc7XHJcbmltcG9ydCB7IENvc21vc0NsaWVudCB9IGZyb20gJ0BhenVyZS9jb3Ntb3MnO1xyXG5pbXBvcnQge0NvbnRleHR9IGZyb20gJ0BhenVyZS9mdW5jdGlvbnMnXHJcblxyXG5jb25zdCBjbGllbnQgPSBuZXcgQ29zbW9zQ2xpZW50KHByb2Nlc3MuZW52LkNPU01PU19DT05ORUNUSU9OX1NUUklORyBhcyBzdHJpbmcpO1xyXG5jb25zdCBkYXRhYmFzZSA9IGNsaWVudC5kYXRhYmFzZShwcm9jZXNzLmVudi5EQVRBQkFTRV9OQU1FIGFzIHN0cmluZyk7XHJcbmNvbnN0IGNvbnRhaW5lciA9IGRhdGFiYXNlLmNvbnRhaW5lcihwcm9jZXNzLmVudi5UT0RPU19DT05UQUlORVIgYXMgc3RyaW5nKTtcclxuXHJcbi8vIEdyYXBoUUwgU2NoZW1hXHJcbmNvbnN0IHR5cGVEZWZzID0gZ3FsYFxyXG4gIHR5cGUgVG9kbyB7XHJcbiAgICBpZDogSUQhXHJcbiAgICB0aXRsZTogU3RyaW5nIVxyXG4gICAgZG9uZTogQm9vbGVhbiFcclxuICB9XHJcblxyXG4gIGlucHV0IFRvZG9JbnB1dCB7XHJcbiAgICBpZDogSUQhXHJcbiAgICB0aXRsZTogU3RyaW5nIVxyXG4gICAgZG9uZTogQm9vbGVhbiFcclxuICB9XHJcblxyXG4gIHR5cGUgUXVlcnkge1xyXG4gICAgZ2V0VG9kb3M6IFtUb2RvXVxyXG4gIH1cclxuXHJcbiAgdHlwZSBNdXRhdGlvbiB7XHJcbiAgICBhZGRUb2RvKHRvZG86IFRvZG9JbnB1dCEpOiBUb2RvXHJcbiAgICB1cGRhdGVUb2RvKHRvZG86IFRvZG9JbnB1dCEpOiBUb2RvXHJcbiAgICBkZWxldGVUb2RvKHRvZG9JZDogU3RyaW5nISk6IFN0cmluZ1xyXG4gIH1cclxuYDtcclxuXHJcbi8vIFJlc29sdmVyc1xyXG5jb25zdCByZXNvbHZlcnMgPSB7XHJcbiAgUXVlcnk6IHtcclxuICAgIGdldFRvZG9zOiBhc3luYyAoXzogYW55LCBfXzogYW55LCBjb250ZXh0OiBDb250ZXh0KSA9PiB7XHJcbiAgICAgIGNvbnRleHQubG9nKCdGZXRjaGluZyBhbGwgdG9kb3MuLi4nKTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCB7IHJlc291cmNlcyB9ID0gYXdhaXQgY29udGFpbmVyLml0ZW1zLnJlYWRBbGwoKS5mZXRjaEFsbCgpO1xyXG4gICAgICAgIGNvbnRleHQubG9nKGBTdWNjZXNzZnVsbHkgZmV0Y2hlZCAke3Jlc291cmNlcy5sZW5ndGh9IHRvZG9zLmApO1xyXG4gICAgICAgIGNvbnN0IGxpc3RPZkRhdGEgPSByZXNvdXJjZXMubWFwKCh0b2RvOiBhbnkpID0+ICh7XHJcbiAgICAgICAgICBpZDogdG9kby5pZCxcclxuICAgICAgICAgIHRpdGxlOiB0b2RvLnRpdGxlLFxyXG4gICAgICAgICAgZG9uZTogdG9kby5kb25lLFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgIFxyXG4gICAgICAgIGNvbnRleHQubG9nKGBTdWNjZXNzZnVsbHkgZmV0Y2hlZCBMaXN0YCxsaXN0T2ZEYXRhKTtcclxuICAgICAgICByZXR1cm4gbGlzdE9mRGF0YTtcclxuXHJcbiAgICAgICAgXHJcblxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnRleHQubG9nKCdFcnJvciBmZXRjaGluZyB0b2RvczonLCBlcnJvcik7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGYWlsZWQgdG8gZmV0Y2ggdG9kb3MuJyk7XHJcbiAgICAgIH1cclxuICAgIH0sXHJcbiAgfSxcclxuICBNdXRhdGlvbjoge1xyXG4gICAgYWRkVG9kbzogYXN5bmMgKF86IGFueSwgeyB0b2RvIH06IGFueSwgY29udGV4dDogQ29udGV4dCkgPT4ge1xyXG4gICAgICBjb250ZXh0LmxvZygnQWRkaW5nIGEgbmV3IHRvZG8uLi4nKTtcclxuICAgICAgY29uc29sZS5sb2coJ0FkZGluZyBhIG5ldyB0b2RvLi4uJylcclxuICAgICAgY29uc3QgbmV3VG9kbyA9IHtcclxuICAgICAgICBpZDogdG9kby5pZCxcclxuICAgICAgICB0aXRsZTogdG9kby50aXRsZSxcclxuICAgICAgICBkb25lOiB0b2RvLmRvbmUgfHwgZmFsc2UsIC8vIERlZmF1bHQgdmFsdWUgZm9yIGRvbmVcclxuICAgICAgfTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCB7IHJlc291cmNlIH0gPSBhd2FpdCBjb250YWluZXIuaXRlbXMuY3JlYXRlKG5ld1RvZG8pO1xyXG4gICAgICAgIGNvbnRleHQubG9nKCdUb2RvIGFkZGVkIHN1Y2Nlc3NmdWxseTonLCByZXNvdXJjZSk7XHJcbiAgICAgICAgaWYgKCFyZXNvdXJjZSkge1xyXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGYWlsZWQgdG8gY3JlYXRlIHRvZG8uJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBpZDogcmVzb3VyY2UuaWQsXHJcbiAgICAgICAgICB0aXRsZTogcmVzb3VyY2UudGl0bGUsXHJcbiAgICAgICAgICBkb25lOiByZXNvdXJjZS5kb25lLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29udGV4dC5sb2coJ0Vycm9yIGFkZGluZyB0b2RvOicsIGVycm9yKTtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ZhaWxlZCB0byBhZGQgdG9kby4nKTtcclxuICAgICAgfVxyXG4gICAgfSxcclxuICAgIHVwZGF0ZVRvZG86IGFzeW5jIChfOiBhbnksIHsgdG9kbyB9OiBhbnksIGNvbnRleHQ6IENvbnRleHQgKSA9PiB7XHJcbiAgICAgIGNvbnRleHQubG9nKGBVcGRhdGluZyB0b2RvIHdpdGggSUQ6ICR7dG9kby5pZH1gKTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBwYXJ0aXRpb25LZXlWYWx1ZSA9IHRvZG8uaWQ7XHJcbiAgICAgICAgY29uc3QgeyByZXNvdXJjZSB9ID0gYXdhaXQgY29udGFpbmVyLml0ZW0odG9kby5pZCxwYXJ0aXRpb25LZXlWYWx1ZSkucmVhZCgpO1xyXG4gICAgICAgIGNvbnN0IHVwZGF0ZWRUb2RvID0geyAuLi5yZXNvdXJjZSwgdGl0bGU6IHRvZG8udGl0bGUsIGRvbmU6IHRvZG8uZG9uZSB9O1xyXG5cclxuICAgICAgICBjb25zdCB7IHJlc291cmNlOiB1cGRhdGVkUmVzb3VyY2UgfSA9IGF3YWl0IGNvbnRhaW5lci5pdGVtKHRvZG8uaWQscGFydGl0aW9uS2V5VmFsdWUpLnJlcGxhY2UodXBkYXRlZFRvZG8pO1xyXG4gICAgICAgIGNvbnRleHQubG9nKCdUb2RvIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5OicsIHVwZGF0ZWRSZXNvdXJjZSk7XHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZWRSZXNvdXJjZTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb250ZXh0LmxvZygnRXJyb3IgdXBkYXRpbmcgdG9kbzonLCBlcnJvcik7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGYWlsZWQgdG8gdXBkYXRlIHRvZG8uJyk7XHJcbiAgICAgIH1cclxuICAgIH0sXHJcbiAgICBkZWxldGVUb2RvOiBhc3luYyAoXzogYW55LCB7IHRvZG9JZCB9OiBhbnksIGNvbnRleHQ6IENvbnRleHQgKSA9PiB7XHJcblxyXG5cclxuICAgICAgY29udGV4dC5sb2coYERlbGV0aW5nIHRvZG8gd2l0aCBJRDogJHt0b2RvSWR9YCk7XHJcbiAgICAgXHJcbiAgICAgIHRyeSB7XHJcblxyXG4gICAgICAgICAgICAgLy8gUmVwbGFjZSBgPHBhcnRpdGlvbktleVZhbHVlPmAgd2l0aCB0aGUgYWN0dWFsIHBhcnRpdGlvbiBrZXkgdmFsdWUgZm9yIHRoZSB0b2Rvcy5cclxuICAgICAgICAgICAgY29uc3QgcGFydGl0aW9uS2V5VmFsdWUgPSB0b2RvSWQ7IC8vIEFzc3VtaW5nIGBpZGAgaXMgdXNlZCBhcyB0aGUgcGFydGl0aW9uIGtleVxyXG4gICAgICAgIGNvbnN0IHJlc291cmNlMSA9IGF3YWl0IGNvbnRhaW5lci5pdGVtKHRvZG9JZCxwYXJ0aXRpb25LZXlWYWx1ZSkucmVhZCgpO1xyXG4gICAgICAgIGNvbnRleHQubG9nKGBOVU1CRVIgLSByZXNvdXJjZTEgYCxyZXNvdXJjZTEpO1xyXG4gICAgICAgIGNvbnN0IHsgcmVzb3VyY2U6IGV4aXN0aW5nVG9kbyB9ID0gYXdhaXQgY29udGFpbmVyLml0ZW0odG9kb0lkLCBwYXJ0aXRpb25LZXlWYWx1ZSkucmVhZCgpO1xyXG5cclxuICAgICAgICBpZiAoIWV4aXN0aW5nVG9kbykge1xyXG4gICAgICAgICAgY29udGV4dC5sb2coYFRvZG8gd2l0aCBJRCAke3RvZG9JZH0gZG9lcyBub3QgZXhpc3QuYCk7XHJcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFRvZG8gd2l0aCBJRCAke3RvZG9JZH0gZG9lcyBub3QgZXhpc3QuYCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb250ZXh0LmxvZyhgVG9kbyB3aXRoIElEICR7dG9kb0lkfSBkb2VzIGV4aXN0LmApO1xyXG5cclxuICAgICAgICBhd2FpdCBjb250YWluZXIuaXRlbSh0b2RvSWQscGFydGl0aW9uS2V5VmFsdWUpLmRlbGV0ZSgpO1xyXG5cclxuICAgICAgICBjb250ZXh0LmxvZyhgVG9kbyB3aXRoIElEICR7dG9kb0lkfSBkZWxldGVkIHN1Y2Nlc3NmdWxseS5gKTtcclxuICAgICAgICByZXR1cm4gdG9kb0lkO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnRleHQubG9nKCdFcnJvciBkZWxldGluZyB0b2RvOicsIGVycm9yKTtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ZhaWxlZCB0byBkZWxldGUgdG9kby4nKTtcclxuICAgICAgfVxyXG4gICAgfSxcclxuICB9LFxyXG59O1xyXG5cclxuLy8gQXBvbGxvIFNlcnZlciBzZXR1cFxyXG5jb25zdCBzZXJ2ZXIgPSBuZXcgQXBvbGxvU2VydmVyKHtcclxuICB0eXBlRGVmcyxcclxuICByZXNvbHZlcnMsXHJcbiAgY29udGV4dDogKHsgY29udGV4dCB9OiB7IGNvbnRleHQ6IENvbnRleHQgIH0pID0+IGNvbnRleHQsXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNvbnN0IG1haW4gPSAoY29udGV4dDogQ29udGV4dCAsIHJlcTogYW55KSA9PiB7XHJcbiAgY29udGV4dC5sb2coJ1JlY2VpdmVkIHJlcXVlc3Q6JywgcmVxLmJvZHkpO1xyXG4gIHJldHVybiBzZXJ2ZXIuY3JlYXRlSGFuZGxlcigpKGNvbnRleHQsIHJlcSk7XHJcbn07XHJcbiJdfQ==