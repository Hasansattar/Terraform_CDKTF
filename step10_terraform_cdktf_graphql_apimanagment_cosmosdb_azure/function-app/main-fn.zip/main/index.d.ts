import { Context } from '@azure/functions';
export declare const main: (context: Context, req: any) => void;
