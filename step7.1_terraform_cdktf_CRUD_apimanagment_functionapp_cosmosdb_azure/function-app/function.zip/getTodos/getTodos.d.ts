declare function getTodos(): Promise<any[] | null>;
export default getTodos;
