import { Context, HttpRequest } from "@azure/functions";
declare const main: (context: Context, req: HttpRequest) => Promise<void>;
export default main;
