"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const addTodo_1 = require("../addTodo/addTodo");
const deleteTodo_1 = require("../deleteTodo/deleteTodo");
const getTodos_1 = require("../getTodos/getTodos");
const updateTodo_1 = require("../updateTodo/updateTodo");
// type Todo = {
//     id: string;
//     title: string;
//     done: boolean;
// };
// type AppSyncEvent = {
//     info: {
//         fieldName: string;
//     };
//     arguments: {
//         todoId?: string; // Made optional since not all fields require todoId
//         todo?: Todo; // Made optional since not all fields require todo
//     };
// };
const main = async (context, req) => {
    var _a;
    context.log("req===>", req);
    const event = req.body; // Get event from the HTTP request body
    context.log("event===>", event);
    context.log("==============================================");
    context.log("==============================================");
    context.log("req===>", req);
    context.log("event.info===>", event.info);
    context.log("event.info.fieldName===>", event.info.fieldName);
    try {
        switch (event.info.fieldName) {
            case "addTodo":
                // Check if todo is defined before passing to addTodo
                if (!event.arguments.todo) {
                    context.res = {
                        status: 400,
                        body: "Todo is required.",
                    };
                    return;
                }
                const addedTodo = await (0, addTodo_1.default)((_a = event.arguments) === null || _a === void 0 ? void 0 : _a.todo);
                context.log("========>", addedTodo);
                context.res = {
                    status: 200,
                    body: addedTodo,
                };
                break;
            case "getTodos":
                const todos = await (0, getTodos_1.default)();
                context.res = {
                    status: 200,
                    body: todos,
                };
                break;
            case "deleteTodo":
                // Check if todoId is defined before passing to deleteTodo
                if (!event.arguments.todoId) {
                    context.res = {
                        status: 400,
                        body: "Todo ID is required.",
                    };
                    return;
                }
                const deletedTodoId = await (0, deleteTodo_1.default)(event.arguments.todoId);
                context.res = {
                    status: 200,
                    body: deletedTodoId,
                };
                break;
            case "updateTodo":
                // Check if todo is defined before passing to updateTodo
                if (!event.arguments.todo) {
                    context.res = {
                        status: 400,
                        body: "Todo is required.",
                    };
                    return;
                }
                const updatedTodo = await (0, updateTodo_1.default)(event.arguments.todo);
                context.res = {
                    status: 200,
                    body: updatedTodo,
                };
                break;
            default:
                context.res = {
                    status: 400,
                    body: "Unsupported operation.",
                };
                break;
        }
    }
    catch (error) {
        console.log('Error processing request: ', error);
        context.res = {
            status: 500,
            body: "Internal server error.",
        };
    }
};
exports.default = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIm1haW4udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFDQSxnREFBeUM7QUFDekMseURBQWtEO0FBQ2xELG1EQUE0QztBQUM1Qyx5REFBa0Q7QUFFbEQsZ0JBQWdCO0FBQ2hCLGtCQUFrQjtBQUNsQixxQkFBcUI7QUFDckIscUJBQXFCO0FBQ3JCLEtBQUs7QUFFTCx3QkFBd0I7QUFDeEIsY0FBYztBQUNkLDZCQUE2QjtBQUM3QixTQUFTO0FBQ1QsbUJBQW1CO0FBQ25CLGdGQUFnRjtBQUNoRiwwRUFBMEU7QUFFMUUsU0FBUztBQUNULEtBQUs7QUFFTCxNQUFNLElBQUksR0FBRyxLQUFLLEVBQUUsT0FBZSxFQUFFLEdBQWUsRUFBRSxFQUFFOztJQUNwRCxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBQyxHQUFHLENBQUMsQ0FBQTtJQUMxQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsdUNBQXVDO0lBRTlELE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFDLEtBQUssQ0FBQyxDQUFBO0lBQzlCLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0RBQWdELENBQUMsQ0FBQTtJQUM3RCxPQUFPLENBQUMsR0FBRyxDQUFDLGdEQUFnRCxDQUFDLENBQUE7SUFFN0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUMsR0FBRyxDQUFDLENBQUE7SUFHMUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUE7SUFHeEMsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsRUFBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFBO0lBRTdELElBQUksQ0FBQztRQUNELFFBQVEsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUMzQixLQUFLLFNBQVM7Z0JBQ1QscURBQXFEO2dCQUNyRCxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDekIsT0FBTyxDQUFDLEdBQUcsR0FBRzt3QkFDVixNQUFNLEVBQUUsR0FBRzt3QkFDWCxJQUFJLEVBQUUsbUJBQW1CO3FCQUM1QixDQUFDO29CQUNGLE9BQU87Z0JBQ1gsQ0FBQztnQkFFRCxNQUFNLFNBQVMsR0FBRyxNQUFNLElBQUEsaUJBQU8sRUFBQyxNQUFBLEtBQUssQ0FBQyxTQUFTLDBDQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN2RCxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBQyxTQUFTLENBQUMsQ0FBQztnQkFDbkMsT0FBTyxDQUFDLEdBQUcsR0FBRztvQkFDVixNQUFNLEVBQUUsR0FBRztvQkFDWCxJQUFJLEVBQUUsU0FBUztpQkFDbEIsQ0FBQztnQkFDRixNQUFNO1lBRVYsS0FBSyxVQUFVO2dCQUNYLE1BQU0sS0FBSyxHQUFHLE1BQU0sSUFBQSxrQkFBUSxHQUFFLENBQUM7Z0JBQy9CLE9BQU8sQ0FBQyxHQUFHLEdBQUc7b0JBQ1YsTUFBTSxFQUFFLEdBQUc7b0JBQ1gsSUFBSSxFQUFFLEtBQUs7aUJBQ2QsQ0FBQztnQkFDRixNQUFNO1lBRVYsS0FBSyxZQUFZO2dCQUNiLDBEQUEwRDtnQkFDMUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUM7b0JBQzFCLE9BQU8sQ0FBQyxHQUFHLEdBQUc7d0JBQ1YsTUFBTSxFQUFFLEdBQUc7d0JBQ1gsSUFBSSxFQUFFLHNCQUFzQjtxQkFDL0IsQ0FBQztvQkFDRixPQUFPO2dCQUNYLENBQUM7Z0JBQ0QsTUFBTSxhQUFhLEdBQUcsTUFBTSxJQUFBLG9CQUFVLEVBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDL0QsT0FBTyxDQUFDLEdBQUcsR0FBRztvQkFDVixNQUFNLEVBQUUsR0FBRztvQkFDWCxJQUFJLEVBQUUsYUFBYTtpQkFDdEIsQ0FBQztnQkFDRixNQUFNO1lBRVYsS0FBSyxZQUFZO2dCQUNaLHdEQUF3RDtnQkFDeEQsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ3pCLE9BQU8sQ0FBQyxHQUFHLEdBQUc7d0JBQ1YsTUFBTSxFQUFFLEdBQUc7d0JBQ1gsSUFBSSxFQUFFLG1CQUFtQjtxQkFDNUIsQ0FBQztvQkFDRixPQUFPO2dCQUNYLENBQUM7Z0JBQ0QsTUFBTSxXQUFXLEdBQUcsTUFBTSxJQUFBLG9CQUFVLEVBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDM0QsT0FBTyxDQUFDLEdBQUcsR0FBRztvQkFDVixNQUFNLEVBQUUsR0FBRztvQkFDWCxJQUFJLEVBQUUsV0FBVztpQkFDcEIsQ0FBQztnQkFDRixNQUFNO1lBRVY7Z0JBQ0ksT0FBTyxDQUFDLEdBQUcsR0FBRztvQkFDVixNQUFNLEVBQUUsR0FBRztvQkFDWCxJQUFJLEVBQUUsd0JBQXdCO2lCQUNqQyxDQUFDO2dCQUNGLE1BQU07UUFDZCxDQUFDO0lBQ0wsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDYixPQUFPLENBQUMsR0FBRyxDQUFDLDRCQUE0QixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ2pELE9BQU8sQ0FBQyxHQUFHLEdBQUc7WUFDVixNQUFNLEVBQUUsR0FBRztZQUNYLElBQUksRUFBRSx3QkFBd0I7U0FDakMsQ0FBQztJQUNOLENBQUM7QUFDTCxDQUFDLENBQUM7QUFFRixrQkFBZSxJQUFJLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb250ZXh0LEh0dHBSZXF1ZXN0IH0gZnJvbSBcIkBhenVyZS9mdW5jdGlvbnNcIjtcclxuaW1wb3J0IGFkZFRvZG8gZnJvbSBcIi4uL2FkZFRvZG8vYWRkVG9kb1wiO1xyXG5pbXBvcnQgZGVsZXRlVG9kbyBmcm9tIFwiLi4vZGVsZXRlVG9kby9kZWxldGVUb2RvXCI7XHJcbmltcG9ydCBnZXRUb2RvcyBmcm9tIFwiLi4vZ2V0VG9kb3MvZ2V0VG9kb3NcIjtcclxuaW1wb3J0IHVwZGF0ZVRvZG8gZnJvbSBcIi4uL3VwZGF0ZVRvZG8vdXBkYXRlVG9kb1wiO1xyXG5cclxuLy8gdHlwZSBUb2RvID0ge1xyXG4vLyAgICAgaWQ6IHN0cmluZztcclxuLy8gICAgIHRpdGxlOiBzdHJpbmc7XHJcbi8vICAgICBkb25lOiBib29sZWFuO1xyXG4vLyB9O1xyXG5cclxuLy8gdHlwZSBBcHBTeW5jRXZlbnQgPSB7XHJcbi8vICAgICBpbmZvOiB7XHJcbi8vICAgICAgICAgZmllbGROYW1lOiBzdHJpbmc7XHJcbi8vICAgICB9O1xyXG4vLyAgICAgYXJndW1lbnRzOiB7XHJcbi8vICAgICAgICAgdG9kb0lkPzogc3RyaW5nOyAvLyBNYWRlIG9wdGlvbmFsIHNpbmNlIG5vdCBhbGwgZmllbGRzIHJlcXVpcmUgdG9kb0lkXHJcbi8vICAgICAgICAgdG9kbz86IFRvZG87IC8vIE1hZGUgb3B0aW9uYWwgc2luY2Ugbm90IGFsbCBmaWVsZHMgcmVxdWlyZSB0b2RvXHJcbiAgICAgICAgXHJcbi8vICAgICB9O1xyXG4vLyB9O1xyXG5cclxuY29uc3QgbWFpbiA9IGFzeW5jIChjb250ZXh0OkNvbnRleHQsIHJlcTpIdHRwUmVxdWVzdCkgPT4ge1xyXG4gICAgY29udGV4dC5sb2coXCJyZXE9PT0+XCIscmVxKVxyXG4gICAgY29uc3QgZXZlbnQgPSByZXEuYm9keTsgLy8gR2V0IGV2ZW50IGZyb20gdGhlIEhUVFAgcmVxdWVzdCBib2R5XHJcblxyXG4gICAgIGNvbnRleHQubG9nKFwiZXZlbnQ9PT0+XCIsZXZlbnQpXHJcbiAgICAgY29udGV4dC5sb2coXCI9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XCIpXHJcbiAgICAgY29udGV4dC5sb2coXCI9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XCIpXHJcblxyXG4gICAgIGNvbnRleHQubG9nKFwicmVxPT09PlwiLHJlcSlcclxuXHJcblxyXG4gICAgIGNvbnRleHQubG9nKFwiZXZlbnQuaW5mbz09PT5cIixldmVudC5pbmZvKVxyXG5cclxuXHJcbiAgICAgY29udGV4dC5sb2coXCJldmVudC5pbmZvLmZpZWxkTmFtZT09PT5cIixldmVudC5pbmZvLmZpZWxkTmFtZSlcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICAgIHN3aXRjaCAoZXZlbnQuaW5mby5maWVsZE5hbWUpIHtcclxuICAgICAgICAgICAgY2FzZSBcImFkZFRvZG9cIjpcclxuICAgICAgICAgICAgICAgICAvLyBDaGVjayBpZiB0b2RvIGlzIGRlZmluZWQgYmVmb3JlIHBhc3NpbmcgdG8gYWRkVG9kb1xyXG4gICAgICAgICAgICAgICAgIGlmICghZXZlbnQuYXJndW1lbnRzLnRvZG8pIHtcclxuICAgICAgICAgICAgICAgICAgICBjb250ZXh0LnJlcyA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiA0MDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvZHk6IFwiVG9kbyBpcyByZXF1aXJlZC5cIixcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBjb25zdCBhZGRlZFRvZG8gPSBhd2FpdCBhZGRUb2RvKGV2ZW50LmFyZ3VtZW50cz8udG9kbyk7XHJcbiAgICAgICAgICAgICAgICBjb250ZXh0LmxvZyhcIj09PT09PT09PlwiLGFkZGVkVG9kbyk7XHJcbiAgICAgICAgICAgICAgICBjb250ZXh0LnJlcyA9IHtcclxuICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IDIwMCxcclxuICAgICAgICAgICAgICAgICAgICBib2R5OiBhZGRlZFRvZG8sXHJcbiAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBjYXNlIFwiZ2V0VG9kb3NcIjpcclxuICAgICAgICAgICAgICAgIGNvbnN0IHRvZG9zID0gYXdhaXQgZ2V0VG9kb3MoKTtcclxuICAgICAgICAgICAgICAgIGNvbnRleHQucmVzID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIHN0YXR1czogMjAwLFxyXG4gICAgICAgICAgICAgICAgICAgIGJvZHk6IHRvZG9zLFxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgY2FzZSBcImRlbGV0ZVRvZG9cIjpcclxuICAgICAgICAgICAgICAgIC8vIENoZWNrIGlmIHRvZG9JZCBpcyBkZWZpbmVkIGJlZm9yZSBwYXNzaW5nIHRvIGRlbGV0ZVRvZG9cclxuICAgICAgICAgICAgICAgIGlmICghZXZlbnQuYXJndW1lbnRzLnRvZG9JZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRleHQucmVzID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IDQwMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9keTogXCJUb2RvIElEIGlzIHJlcXVpcmVkLlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY29uc3QgZGVsZXRlZFRvZG9JZCA9IGF3YWl0IGRlbGV0ZVRvZG8oZXZlbnQuYXJndW1lbnRzLnRvZG9JZCk7XHJcbiAgICAgICAgICAgICAgICBjb250ZXh0LnJlcyA9IHtcclxuICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IDIwMCxcclxuICAgICAgICAgICAgICAgICAgICBib2R5OiBkZWxldGVkVG9kb0lkLFxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgY2FzZSBcInVwZGF0ZVRvZG9cIjpcclxuICAgICAgICAgICAgICAgICAvLyBDaGVjayBpZiB0b2RvIGlzIGRlZmluZWQgYmVmb3JlIHBhc3NpbmcgdG8gdXBkYXRlVG9kb1xyXG4gICAgICAgICAgICAgICAgIGlmICghZXZlbnQuYXJndW1lbnRzLnRvZG8pIHtcclxuICAgICAgICAgICAgICAgICAgICBjb250ZXh0LnJlcyA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiA0MDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvZHk6IFwiVG9kbyBpcyByZXF1aXJlZC5cIixcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWRUb2RvID0gYXdhaXQgdXBkYXRlVG9kbyhldmVudC5hcmd1bWVudHMudG9kbyk7XHJcbiAgICAgICAgICAgICAgICBjb250ZXh0LnJlcyA9IHtcclxuICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IDIwMCxcclxuICAgICAgICAgICAgICAgICAgICBib2R5OiB1cGRhdGVkVG9kbyxcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICBjb250ZXh0LnJlcyA9IHtcclxuICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IDQwMCxcclxuICAgICAgICAgICAgICAgICAgICBib2R5OiBcIlVuc3VwcG9ydGVkIG9wZXJhdGlvbi5cIixcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdFcnJvciBwcm9jZXNzaW5nIHJlcXVlc3Q6ICcsIGVycm9yKTtcclxuICAgICAgICBjb250ZXh0LnJlcyA9IHtcclxuICAgICAgICAgICAgc3RhdHVzOiA1MDAsXHJcbiAgICAgICAgICAgIGJvZHk6IFwiSW50ZXJuYWwgc2VydmVyIGVycm9yLlwiLFxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBtYWluO1xyXG4iXX0=