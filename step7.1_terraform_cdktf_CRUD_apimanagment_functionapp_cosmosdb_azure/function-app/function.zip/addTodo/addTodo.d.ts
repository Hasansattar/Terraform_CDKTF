type Todo = {
    id: string;
    title: string;
    done: boolean;
};
declare function addTodo(todo: Todo): Promise<({
    id: string;
    title: string;
    done: boolean;
} & import("@azure/cosmos").Resource) | null | undefined>;
export default addTodo;
