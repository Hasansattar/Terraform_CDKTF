"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const cosmos_1 = require("@azure/cosmos");
// Initialize Cosmos DB Client
const client = new cosmos_1.CosmosClient(process.env.COSMOS_CONNECTION_STRING || "");
const database = client.database(process.env.DATABASE_NAME || ""); // Set your database name
const container = database.container(process.env.TODOS_CONTAINER || ""); // Set your container name
async function addTodo(todo) {
    try {
        console.log("====>todo", todo);
        console.log("client====>", client);
        console.log("database====>", database);
        console.log("container====>", container);
        // context.log("====>todo",todo);
        // context.log("client====>",client);
        // context.log("database====>",database);
        // context.log("container====>",container);
        const item = {
            id: todo.id,
            title: todo.title,
            done: todo.done,
        };
        console.log("item==>", item);
        const { resource: createdTodo } = await container.items.create(item);
        return createdTodo;
    }
    catch (err) {
        console.log("CosmosDB error:", err.message || err);
        throw new Error("Error creating the Todo item in CosmosDB: " + err.message);
        return null;
    }
}
exports.default = addTodo;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWRkVG9kby5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImFkZFRvZG8udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSwwQ0FBNkM7QUFTN0MsOEJBQThCO0FBQzlCLE1BQU0sTUFBTSxHQUFHLElBQUkscUJBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixJQUFJLEVBQUUsQ0FBQyxDQUFDO0FBQzVFLE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBRSx5QkFBeUI7QUFDN0YsTUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFFLDBCQUEwQjtBQU9wRyxLQUFLLFVBQVUsT0FBTyxDQUFDLElBQVU7SUFFL0IsSUFBRyxDQUFDO1FBR0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUMsSUFBSSxDQUFDLENBQUM7UUFFOUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUMsTUFBTSxDQUFDLENBQUM7UUFDbEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLEVBQUMsUUFBUSxDQUFDLENBQUM7UUFDdEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBQyxTQUFTLENBQUMsQ0FBQztRQUV4QyxpQ0FBaUM7UUFFakMscUNBQXFDO1FBQ3JDLHlDQUF5QztRQUN6QywyQ0FBMkM7UUFFM0MsTUFBTSxJQUFJLEdBQUc7WUFDWCxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7WUFDWCxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7WUFDakIsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO1NBQ2hCLENBQUM7UUFFRixPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsQ0FBQztRQUcxQixNQUFNLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBRSxHQUFHLE1BQU0sU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDckUsT0FBTyxXQUFXLENBQUM7SUFDckIsQ0FBQztJQUFDLE9BQU8sR0FBTyxFQUFFLENBQUM7UUFDakIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLENBQUMsT0FBTyxJQUFJLEdBQUcsQ0FBQyxDQUFDO1FBQ25ELE1BQU0sSUFBSSxLQUFLLENBQUMsNENBQTRDLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzVFLE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztBQUNILENBQUM7QUFFRCxrQkFBZSxPQUFPLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb3Ntb3NDbGllbnQgfSBmcm9tIFwiQGF6dXJlL2Nvc21vc1wiO1xyXG4vLyBpbXBvcnQgeyBDb250ZXh0IH0gZnJvbSBcIkBhenVyZS9mdW5jdGlvbnNcIjtcclxuXHJcbnR5cGUgVG9kbyA9IHtcclxuICBpZDogc3RyaW5nO1xyXG4gIHRpdGxlOiBzdHJpbmc7XHJcbiAgZG9uZTogYm9vbGVhbjtcclxufTtcclxuXHJcbi8vIEluaXRpYWxpemUgQ29zbW9zIERCIENsaWVudFxyXG5jb25zdCBjbGllbnQgPSBuZXcgQ29zbW9zQ2xpZW50KHByb2Nlc3MuZW52LkNPU01PU19DT05ORUNUSU9OX1NUUklORyB8fCBcIlwiKTtcclxuY29uc3QgZGF0YWJhc2UgPSBjbGllbnQuZGF0YWJhc2UocHJvY2Vzcy5lbnYuREFUQUJBU0VfTkFNRSB8fCBcIlwiKTsgIC8vIFNldCB5b3VyIGRhdGFiYXNlIG5hbWVcclxuY29uc3QgY29udGFpbmVyID0gZGF0YWJhc2UuY29udGFpbmVyKHByb2Nlc3MuZW52LlRPRE9TX0NPTlRBSU5FUiB8fCBcIlwiKTsgIC8vIFNldCB5b3VyIGNvbnRhaW5lciBuYW1lXHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGFkZFRvZG8odG9kbzogVG9kbykge1xyXG5cclxuICB0cnl7XHJcblxyXG4gIFxyXG4gIGNvbnNvbGUubG9nKFwiPT09PT50b2RvXCIsdG9kbyk7XHJcblxyXG4gIGNvbnNvbGUubG9nKFwiY2xpZW50PT09PT5cIixjbGllbnQpO1xyXG4gIGNvbnNvbGUubG9nKFwiZGF0YWJhc2U9PT09PlwiLGRhdGFiYXNlKTtcclxuICBjb25zb2xlLmxvZyhcImNvbnRhaW5lcj09PT0+XCIsY29udGFpbmVyKTtcclxuXHJcbiAgLy8gY29udGV4dC5sb2coXCI9PT09PnRvZG9cIix0b2RvKTtcclxuXHJcbiAgLy8gY29udGV4dC5sb2coXCJjbGllbnQ9PT09PlwiLGNsaWVudCk7XHJcbiAgLy8gY29udGV4dC5sb2coXCJkYXRhYmFzZT09PT0+XCIsZGF0YWJhc2UpO1xyXG4gIC8vIGNvbnRleHQubG9nKFwiY29udGFpbmVyPT09PT5cIixjb250YWluZXIpO1xyXG5cclxuICBjb25zdCBpdGVtID0ge1xyXG4gICAgaWQ6IHRvZG8uaWQsXHJcbiAgICB0aXRsZTogdG9kby50aXRsZSxcclxuICAgIGRvbmU6IHRvZG8uZG9uZSxcclxuICB9O1xyXG5cclxuICBjb25zb2xlLmxvZyhcIml0ZW09PT5cIixpdGVtKTtcclxuXHJcbiAgXHJcbiAgICBjb25zdCB7IHJlc291cmNlOiBjcmVhdGVkVG9kbyB9ID0gYXdhaXQgY29udGFpbmVyLml0ZW1zLmNyZWF0ZShpdGVtKTtcclxuICAgIHJldHVybiBjcmVhdGVkVG9kbztcclxuICB9IGNhdGNoIChlcnI6YW55KSB7XHJcbiAgICBjb25zb2xlLmxvZyhcIkNvc21vc0RCIGVycm9yOlwiLCBlcnIubWVzc2FnZSB8fCBlcnIpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRXJyb3IgY3JlYXRpbmcgdGhlIFRvZG8gaXRlbSBpbiBDb3Ntb3NEQjogXCIgKyBlcnIubWVzc2FnZSk7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGFkZFRvZG87XHJcbiJdfQ==