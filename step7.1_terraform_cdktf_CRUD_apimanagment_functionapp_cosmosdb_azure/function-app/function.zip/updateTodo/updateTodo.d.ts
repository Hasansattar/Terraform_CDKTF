type Todo = {
    id: string;
    [key: string]: any;
};
declare function updateTodo(todo: Todo): Promise<Todo | null>;
export default updateTodo;
