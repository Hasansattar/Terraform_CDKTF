type Todo = {
    id: string;
    title: string;
    done: boolean;
};
declare function addTodo(todo: Todo): Promise<Todo | null>;
export default addTodo;
