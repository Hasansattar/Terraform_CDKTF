declare function updateTodo(todo: any): Promise<any>;
export default updateTodo;
