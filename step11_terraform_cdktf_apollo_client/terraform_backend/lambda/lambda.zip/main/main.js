"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const addTodo_1 = require("../addTodo/addTodo");
const deleteTodo_1 = require("../deleteTodo/deleteTodo");
const getTodos_1 = require("../getTodos/getTodos");
const updateTodo_1 = require("../updateTodo/updateTodo");
exports.handler = async (event) => {
    switch (event.info.fieldName) {
        case "addTodo":
            return await (0, addTodo_1.default)(event.arguments.todo);
        case "getTodos":
            return await (0, getTodos_1.default)();
        case "deleteTodo":
            return await (0, deleteTodo_1.default)(event.arguments.todoId);
        case "updateTodo":
            return await (0, updateTodo_1.default)(event.arguments.todo);
        default:
            return null;
    }
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIm1haW4udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxnREFBeUM7QUFDekMseURBQWtEO0FBQ2xELG1EQUE0QztBQUM1Qyx5REFBa0Q7QUFtQmxELE9BQU8sQ0FBQyxPQUFPLEdBQUcsS0FBSyxFQUFFLEtBQW1CLEVBQUUsRUFBRTtJQUM1QyxRQUFRLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFFM0IsS0FBSyxTQUFTO1lBQ1YsT0FBTyxNQUFNLElBQUEsaUJBQU8sRUFBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQy9DLEtBQUssVUFBVTtZQUNYLE9BQU8sTUFBTSxJQUFBLGtCQUFRLEdBQUUsQ0FBQztRQUM1QixLQUFLLFlBQVk7WUFDYixPQUFPLE1BQU0sSUFBQSxvQkFBVSxFQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDcEQsS0FBSyxZQUFZO1lBQ2IsT0FBTyxNQUFNLElBQUEsb0JBQVUsRUFBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2xEO1lBQ0ksT0FBTyxJQUFJLENBQUM7SUFDcEIsQ0FBQztBQUNMLENBQUMsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBhZGRUb2RvIGZyb20gJy4uL2FkZFRvZG8vYWRkVG9kbyc7XHJcbmltcG9ydCBkZWxldGVUb2RvIGZyb20gJy4uL2RlbGV0ZVRvZG8vZGVsZXRlVG9kbyc7XHJcbmltcG9ydCBnZXRUb2RvcyBmcm9tICcuLi9nZXRUb2Rvcy9nZXRUb2Rvcyc7XHJcbmltcG9ydCB1cGRhdGVUb2RvIGZyb20gJy4uL3VwZGF0ZVRvZG8vdXBkYXRlVG9kbyc7XHJcblxyXG5cclxudHlwZSBUb2RvID0ge1xyXG4gIGlkOiBzdHJpbmc7XHJcbiAgdGl0bGU6IHN0cmluZztcclxuICBkb25lOiBib29sZWFuO1xyXG59O1xyXG5cclxudHlwZSBBcHBTeW5jRXZlbnQgPSB7XHJcbiAgICBpbmZvOiB7XHJcbiAgICAgICAgZmllbGROYW1lOiBzdHJpbmdcclxuICAgIH0sXHJcbiAgICBhcmd1bWVudHM6IHtcclxuICAgICAgICB0b2RvSWQ6IHN0cmluZyxcclxuICAgICAgICB0b2RvOiBUb2RvXHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydHMuaGFuZGxlciA9IGFzeW5jIChldmVudDogQXBwU3luY0V2ZW50KSA9PiB7XHJcbiAgICBzd2l0Y2ggKGV2ZW50LmluZm8uZmllbGROYW1lKSB7XHJcblxyXG4gICAgICAgIGNhc2UgXCJhZGRUb2RvXCI6XHJcbiAgICAgICAgICAgIHJldHVybiBhd2FpdCBhZGRUb2RvKGV2ZW50LmFyZ3VtZW50cy50b2RvKTtcclxuICAgICAgICBjYXNlIFwiZ2V0VG9kb3NcIjpcclxuICAgICAgICAgICAgcmV0dXJuIGF3YWl0IGdldFRvZG9zKCk7XHJcbiAgICAgICAgY2FzZSBcImRlbGV0ZVRvZG9cIjpcclxuICAgICAgICAgICAgcmV0dXJuIGF3YWl0IGRlbGV0ZVRvZG8oZXZlbnQuYXJndW1lbnRzLnRvZG9JZCk7XHJcbiAgICAgICAgY2FzZSBcInVwZGF0ZVRvZG9cIjpcclxuICAgICAgICAgICAgcmV0dXJuIGF3YWl0IHVwZGF0ZVRvZG8oZXZlbnQuYXJndW1lbnRzLnRvZG8pO1xyXG4gICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG59Il19