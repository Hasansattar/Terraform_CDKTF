// In-memory storage for demonstration purposes
let todos = [
  { id: '1', title: 'Learn AWS', completed: false },
  { id: '2', title: 'Build a Lambda function', completed: false },
];

// Lambda function handler
exports.handler = async (event) => {
  console.log("Event===========>",event);
  const httpMethod = event.httpMethod;
  
  const path = event.path;
  const responseHeaders = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*", // Allow requests from any origin
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE",
  };

  try {
    switch (httpMethod) {
      case 'GET':
        if (path === '/todos') {
          return {
            statusCode: 200,
            headers: responseHeaders,
            body: JSON.stringify(todos),
          };
        } else if (path.startsWith('/todos/')) {
          const id = path.split('/')[2];
          const todo = todos.find(todo => todo.id === id);
          if (todo) {
            return {
              statusCode: 200,
              headers: responseHeaders,
              body: JSON.stringify(todo),
            };
          } else {
            return {
              statusCode: 404,
              headers: responseHeaders,
              body: JSON.stringify({ message: 'Todo not found' }),
            };
          }
        }
        break;

      case 'POST':
        const newTodo = JSON.parse(event.body);
        newTodo.id = String(todos.length + 1);
        todos.push(newTodo);
        return {
          statusCode: 201,
          headers: responseHeaders,
          body: JSON.stringify(newTodo),
        };

      case 'PUT':
        const updateId = path.split('/')[2];
        const index = todos.findIndex(todo => todo.id === updateId);
        if (index > -1) {
          const updatedTodo = JSON.parse(event.body);
          todos[index] = { id: updateId, ...updatedTodo };
          return {
            statusCode: 200,
            headers: responseHeaders,
            body: JSON.stringify(todos[index]),
          };
        } else {
          return {
            statusCode: 404,
            headers: responseHeaders,
            body: JSON.stringify({ message: 'Todo not found' }),
          };
        }

      case 'DELETE':
        const deleteId = path.split('/')[2];
        todos = todos.filter(todo => todo.id !== deleteId);
        return {
          statusCode: 204,
          headers: responseHeaders,
          body: null,
        };

      default:
        return {
          statusCode: 405,
          headers: responseHeaders,
          body: JSON.stringify({ message: 'Method Not Allowed' }),
        };
    }
  } catch (error) {
    return {
      statusCode: 500,
      headers: responseHeaders,
      body: JSON.stringify({ message: 'Internal hasan Server Error', error: error.message }),
    };
  }
};
